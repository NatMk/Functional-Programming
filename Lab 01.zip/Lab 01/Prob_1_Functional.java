package Prob_1_Functional;

import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class Prob_1_Functional 
{
	static Supplier<Integer> one = ()->1; //returns a value of one
    long value; //value is of type long because it is 64 bit and allows the display of all digits
	static UnaryOperator <Long> factorial_calculator = num -> (num == 1) || (num == 0)? one.get() : (num) * ( Prob_1_Functional.factorial_calculator.apply(num-1) );
	// the UnaryOperator checks for all the conditions of a factorial and recursively calls the lambda expression
	
	public static void main(String[] args) 
	{	
		long factorial;
		
		for(int i = 0; i <= 15; i++) //loop b/n 0 and 15 inclusive to calculate their factorial
		{
			factorial = factorial_calculator.apply((long) i); //factorial is the factorial result of a number from factorial_calculator method and its value is casted to be long
		
			System.out.println(factorial); // prints numbers b/n 0 and 15 inclusive with their factorial value
		}
	}

}
