package Prob_2_Functional;

import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public class Prob_2_Functional 
{
	static Supplier<Integer> one = ()->1; // returns a value of one
	static Supplier<Integer> zero = ()->0; // returns a value of zero
	static UnaryOperator <Integer> fibonacci_calculator = num -> (num == 0) ? zero.get() : (num == 1) || (num == 2)? one.get() : Prob_2_Functional.fibonacci_calculator.apply(num - 1) + ( Prob_2_Functional.fibonacci_calculator.apply(num-2) );
	// the UnaryOperator checks for all the conditions of a factorial and recursively calls the lambda expression
	
	public static void main(String[] args) 
	{
		Integer fibonacci;
	
		for(int i = 0; i <= 15; i++) //loop b/n 0 and 15 inclusive to calculate their fibonacci
		{
			fibonacci =  fibonacci_calculator.apply(i); //fibonacci is the fibonacci result of a number from fibonacci_calculator method 
			System.out.println(fibonacci); // prints numbers b/n 0 and 15 inclusive with their fibonacci value
		}
	}

}
