package Prob_3_Functional;

import java.util.function.BinaryOperator;

public class Prob_3_Functional 
{
	static BinaryOperator <Integer> add = (first_num, second_num) -> first_num + second_num; //returns the sum of the two numbers 
    static BinaryOperator <Integer> GCD_calculator = (num1,num2) -> (num1 == 0) || (num2 == 0)? add.apply(num1, num2) : Prob_3_Functional.GCD_calculator.apply(num2, num1 % num2);
 // the BinaryOperator checks for all the conditions of a factorial and recursively calls the lambda expression
    
	public static void main(String[] args) 
	{
		int GCD;
	
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				GCD = GCD_calculator.apply(i,j); //GCD is the GCD result of two numbers from GCD_calculator method
				System.out.println(GCD); // prints numbers b/n (0,0) to (9,9) with their GCD value
			}
		}
	}
}