package Prob_3_Imperative;

public class Prob_3_Imperative
{

    static int GCD_calculator (int num1, int num2)
	{
		int GCD_value;
		
		if(num1 == 0 || num2 == 0) 
		 {
			 return num1 + num2; //GCD of two 0 and another number or zero is their sum. they are parameters for the method add
		 }
		  GCD_value = GCD_calculator(num2, num1 % num2); //definition of the GCD of two numbers
		  return GCD_value;   //GCD_value contains the GCD result of the two numbers
	}
	
	public static void main(String[] args) 
	{
		
		int GCD;
		
		for (int i = 0; i < 10; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				GCD = GCD_calculator(i,j); //GCD is the GCD result of two numbers from GCD_calculator method
				System.out.println(GCD); // prints numbers b/n (0,0) to (9,9) with their GCD value
			}
		}		
	}

}
