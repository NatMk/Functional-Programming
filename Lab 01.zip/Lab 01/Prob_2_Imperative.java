package Prob_2_Imperative;

public class Prob_2_Imperative 
{
	 static int fibonacci_calculator (int num)
     {
			int fib_value;
			
			if(num == 0) //fibonacci of 0 is defined to be 0
			{
				return 0;
			}
		    if ( (num == 1) || (num == 2) ) //fibonacci of 1 and 2 is defined to be one
			{
				return 1;
			}	
			fib_value = fibonacci_calculator (num-1) + fibonacci_calculator (num-2); //definition of the fibonacci sequence 
			return fib_value; //fib_value contains the fibonacci result of the number 
	 }	
	
	 public static void main(String[] args) 
	 {
		 
		int fibonacci;
		
		for(int i = 0; i <= 15; i++) //loop b/n 0 and 15 inclusive to calculate their fibonacci
		{
			fibonacci = fibonacci_calculator(i); //fibonacci is the fibonacci result of a number from fibonacci_calculator method 
			System.out.println(fibonacci);  // prints numbers b/n 0 and 15 inclusive with their fibonacci value
		}
		
	 }
}
