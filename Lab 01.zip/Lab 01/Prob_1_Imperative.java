package Prob_1_Imperative;

public class Prob_1_Imperative {

	 static long factorial_calculator (int num)
	{
		long value; //value is of type long because it is 64 bit and allows the display of all digits
		
		if ( (num == 1) || (num == 0) ) //factorial of 0 and 1 is defined to be one
		{
			return 1;
		}	
		value = (num) * factorial_calculator (num-1); //definition of factorial  
		return value; //value contains the factorial result of the number 
	}
	
	public static void main(String[] args) 
	{
		long factorial; // factorial is of type long because it is 64 bit and allows the display of all digits
		for(int i = 0; i <= 15; i++) //loop b/n 0 and 15 inclusive to calculate their factorial
		{
			factorial = factorial_calculator(i); //factorial is the factorial result of a number from factorial_calculator method 
			System.out.println(factorial);// prints numbers b/n 0 and 15 inclusive with their factorial value
		}
	}

}
