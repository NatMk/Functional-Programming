/* This file contains the getters and setter methods
 * for each data that was read from the file.
 */
package lab02bPackage;

public class zipCodeClass 
{
	int zipCode;
	private String typeZip;
	private String cityName;
	private String countyName;
	private int estpop;
	
	public zipCodeClass (int zipCode, String typeZip, String cityName, String countyName, int estpop) 
	{
		this.zipCode = zipCode;
		this.typeZip = typeZip;
		this.cityName = cityName;
		this.countyName = countyName;
		this.estpop = estpop;
	}

	public int getzipCode() 
	{
		return zipCode;
	}
	public void setzipCode(int zipCode) 
	{
		this.zipCode = zipCode;
	}
	public String gettypeZip() 
	{
		return typeZip;
	}
	public void settypeZip(String typeZip)
	{
		this.typeZip = typeZip;
	}
	public String getcityName()
	{
		return cityName;
	}
	public void setcityName(String cityName) 
	{
		this.cityName = cityName;
	}
	public String getcountyName()
	{
		return countyName;
	}
	public void setcountyName(String countyName) 
	{
		this.countyName = countyName;
	}
	
	public int getestpop() 
	{
		return estpop;
	}
	public void setestpop(int estpop)
	{
		this.estpop = estpop;
	}		
}
