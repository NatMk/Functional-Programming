package lab02bPackage;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.text.DecimalFormat;

import lab02bPackage.zipCodeClass;

public class FunctionalZipCode 
{

	private static void Populate_The_Array (ArrayList<zipCodeClass> TexasCityArray/*, ArrayList<String> County_List*/) throws FileNotFoundException,IOException 
	{	
		/**values of type string to store values that will be read from the input file "L02a Cityname_wo_headers.csv" **/
		String [] values;
		String line = "";
		String filename = "L02b zip_code_database.csv"; 
		try 
		{
			BufferedReader buffer = new BufferedReader (new FileReader(filename)); /**opens the file for reading using BufferedReader **/ 	
			
			while ((line = buffer.readLine()) != null) /** Process the file until we reach the end of it **/
			{
				values = line.split(","); /**splits the data in the file that is separated by commas**/
				TexasCityArray.add(new zipCodeClass (Integer.parseInt(values[0]),values[1],values[2],values[3],Integer.parseInt(values[4]))); 
				/** This line stores the value that is read from the file into a string of values **/
			}
			
			buffer.close(); /** closes the bufferReader, We have finished reading from the file **/
		} 
		
		  catch (FileNotFoundException e) /**If a problem occurs while trying to open the input file we print a message and safely exit the program **/
		   {
			   System.out.println("The File " + "L02b zip_code_database.csv" + " could not be opened for reading.\n");
			   System.exit(0);
		   }	
				
		   catch(IOException e) /**If a problem occurs while reading from the input file we print a message and safely exit the program **/
		   {
		       System.out.println ("An Error occured while reading the file" + "L02b zip_code_database.csv\"\n");
		       System.exit(0);
		   }				
	}
	
	private static void Sort_The_County (ArrayList<zipCodeClass> TexasCityArray) throws IOException
	{	 
		
		try
		{
			String OutputFile = "Problem_2b_Output.txt";
			PrintWriter file_writer = new PrintWriter(OutputFile);
			
			/**writes a header to the opened file**/
			file_writer.println("County name\tCounty Pop\tCity Name\tCity Pop\tNo.Zip Codes");
			
			/**we sort the counties on A-Z with duplicated and find the population of each county while getting the population and zip code of each city */ 
			TexasCityArray.stream().map(county -> county.getcountyName()).distinct().sorted((county1,county2) -> county1.compareTo(county2))
			.forEach(p -> 
			{
				int total_county_pop = (int)TexasCityArray.stream().filter(txc -> txc.getcountyName().equals(p)).mapToInt(txc -> txc.getestpop()).sum();
				Sort_The_City(TexasCityArray,p,total_county_pop,file_writer);						
		    });
			
			file_writer.close(); /* data has been written to the file */
		}	   
		catch(IOException e) /** If a problem occurs while accessing the output file we print a message and safely exit the program **/
	    {
		       System.out.println ("An Error occured while writing to the file" + "Problem_2b_Output.txt\n");
		       System.exit(0);
		}				   			   
  }
	
  private static void Sort_The_City (ArrayList<zipCodeClass>TexasCityArray,String current_county,int total_county_pop,PrintWriter file_writer)
  {
	  
      ArrayList<String> cty_List = new ArrayList<String>();
      ArrayList<String> City_List = new ArrayList<String>();
      DecimalFormat IntWithComma = new DecimalFormat("###,###,###");
 	 
      cty_List = (ArrayList<String>) TexasCityArray.stream().filter(txc->txc.getcountyName().equals(current_county)).map(txc->txc.getcityName()).distinct().sorted().collect(Collectors.toList());
      City_List.addAll(cty_List); /*City_List contains all the cities of the counties sorted in alphabetic order */
	  
      /*we stream this list in order to get the population and zip code of each city for counties that are the same*/
      
	     City_List.stream()
		    
		.forEach(city->
		{
			int city_pop = TexasCityArray.stream().filter(c->c.getcountyName().equals(current_county)) /*city_pop contains the population of each city in the county */
				          .filter(c->c.getcityName().equals(city)).mapToInt(c->c.getestpop()).reduce(0,Integer::sum);
			
		   	long zipcodes = TexasCityArray.stream() /*zipcodes contains the count of the city in that county*/
				   .filter(c->c.getcityName().equals(city)).mapToInt(c->c.getzipCode()).distinct().count();
		   	
		    /*write the data to a file*/
		    file_writer.print(current_county+"\t"+IntWithComma.format(total_county_pop)+"\t"+city+"\t"+city_pop+"\t"+IntWithComma.format((int)zipcodes));
		    file_writer.println();	/*move to the next line after printing the data for a county */ 
	    });	
	} 

	public static void main(String[] args) throws FileNotFoundException, IOException 
	{ 
		ArrayList<zipCodeClass>TexasCityArray = new ArrayList<zipCodeClass>(); /**TexasCityArray contains all the data that is read from the file**/
		Populate_The_Array(TexasCityArray); /** opens the file for reading, stores the data from the file **/
		Sort_The_County(TexasCityArray); /** implements data for each county that has been sorted **/
		System.out.println("Done Writing to the file: "+ "Problem_2b_Output.txt");		
	}	
}
