package Lab02aPackage;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class FunctionalTexasCities 
{
	private static void Populate_The_Array (ArrayList<texasCitiesClass> TexasCityArray) throws FileNotFoundException,IOException 
	{	
		/**values of type string to store values that will be read from the input file "L02a Cityname_wo_headers.csv" **/
		String [] values;
		String line = "";
		String filename = "L02a Cityname_wo_headers.csv"; 
		try 
		{
			BufferedReader buffer = new BufferedReader (new FileReader(filename)); /**opens the file for reading using BufferedReader **/ 	
			
			while ((line = buffer.readLine()) != null) /** Process the file until we reach the end of it **/
			{
				values = line.split(","); /**splits the data in the file that is separated by commas**/
				TexasCityArray.add(new texasCitiesClass(values[0],values[1],Integer.parseInt(values[2]))); 
				/** This line stores the value that is read from the file into a string of values **/
			}
			
			buffer.close(); /** closes the bufferReader, We have finished reading from the file **/
		} 
	   		
	   catch (FileNotFoundException e) /**If a problem occurs while trying to open the input file we print a message and safely exit the program **/
	   {
		   System.out.println("The File " + "L02a Cityname_wo_headers.csv" + " could not be opened for reading.\n");
		   System.exit(0);
	   }	
			
	   catch(IOException e) /**If a problem occurs while reading from the input file we print a message and safely exit the program **/
	   {
	       System.out.println ("An Error occured while reading the file" + " L02a Cityname_wo_headers.csv.\n");
	       System.exit(0);
	   }			
}

private static void process_the_counties (ArrayList<texasCitiesClass> TexasCityArray, List<String> County_List, String county,long city_count,int total_pop,int large_pop,PrintWriter file_writer)
{	
	        city_count = TexasCityArray.stream().filter(txc-> txc.getCounty().equals(county)) /**checks for a match b/n the county list that is sorted and the array with all counties**/
		 	.count(); /**counts the number of matching counties, city_count will contain the value**/
	      
	          /**checks for a match b/n the county list that is sorted and the array with all counties**/
			  total_pop = TexasCityArray.stream().filter(txc-> txc.getCounty().equals(county))
			 .map(txc -> txc.getPopulation()) /**gets the population of each county**/
			 .reduce(0, Integer::sum); /**Adds all the populations for each county and reduces the value as an integer**/
			  
			  file_writer.print(county); /**prints the county names that was sorted to the file in the 1st column**/
			  
			 file_writer.print("\t"+city_count); /**prints the total cities for a each county to the file in the 2nd column**/
			  
			 file_writer.print("\t"+ total_pop); /**prints the total population for a each county to the file in the 3rd column**/
			 
			 int Avg_pop = total_pop/(int)city_count; /**calculates the average of each county, city_count is casted to integer for division**/
			 file_writer.print("\t"+ Avg_pop); /**prints the Average population for a each county to the file in the 4th column**/
			 
			 String largest_city = ""; /**NULL string to store the largest city for each county**/
			 
			 largest_city = TexasCityArray.stream() /**we stream the exasCityArray to store the largest_city that contains the value of the county**/
			  /**checks for a match b/n the county list that is sorted and the array with all counties**/
			  .filter(txc-> txc.getCounty().equals(county))
			  /**sorts the counties in order of population**/
			  .sorted ((large_city1,large_city2)-> Integer.compare(large_city2.getPopulation(),large_city1.getPopulation()))
			  /**gets the name of the city for the first sorted county by population since it has the highest population **/
			  .findFirst().get().getName();
			 file_writer.print("\t"+ largest_city); /**prints the Largest city for each county in the 5th column**/
			 
			 /**checks for a match b/n the county list that is sorted and the array with all counties**/
			 large_pop = TexasCityArray.stream().filter(txc-> txc.getCounty().equals(county))
					 .map(txc -> txc.getPopulation())/**gets the population of each county**/
					 .max(Comparator.comparing(z->z)).get();/**compares the population of each city to find the largest one**/
			
			 file_writer.print("\t"+ large_pop); /**prints the Largest population for the largest city in county in the last column**/
					 		 
			 file_writer.println(); /**prints new line to for the next county in the file**/
}

private static void Sort_The_Array (ArrayList<texasCitiesClass> TexasCityArray) throws IOException
{	 
	 /** If the file can be accesed without any problems we go ahead and do our data processing and print to the file. 
	  * otherwise the problem will be caught by the catch block 
	  */
		try
		{
			/**variables initialized to store the # of cities, total population and largest population for each county**/
			 long city_count = 0;
			 int total_pop = 0;
			 int large_pop = 0;	 
			
			/**links file_writer to the output file for writing**/
			String OutputFile = "L02a_Functional_Output.txt";
			PrintWriter file_writer = new PrintWriter(OutputFile);
			
			/**writes a header to the opened file**/
			file_writer.println("County name\tNo. Cities\tTotal Pop\tAve Pop\tLargest City\tPopulation");
			
			/**This will create a list of county names sorted A-Z(.sorted) without duplicates(.distinct) from the TexasCityArray ArrayList**/
			 List<String> County_List = TexasCityArray.stream()
			 .map(txc->txc.getCounty()) /**gets the each county from the arrayList**/
			 .distinct() 
			 .sorted() 
			 .collect(Collectors.toList()); /**creates the new list with the list of counties**/
	
			 //System.out.println("County name\tNo. Cities\tTotal Pop\tAve Pop\tLargest City\tPopulation"); 
			 /**we stream the list that contains the county names to process the data for each county**/
			 County_List.stream();
			 for(String county:County_List) 
			 {	/**county is a iterator that loops through the County_List List**/	
				 process_the_counties(TexasCityArray,County_List,county,city_count,total_pop,large_pop,file_writer);	 			
			 }			 
			 
			 file_writer.close();	/** closes the output file the data is being written to **/	
		}
		
		catch(IOException e) /** If a problem occurs while accessing the output file we print a message and safely exit the program **/
	    {
		       System.out.println ("An Error occured while writing to the file" + " L02a_Functional_Output.txt.\n");
		       System.exit(0);
		}			
   }

	public static void main(String[] args) throws FileNotFoundException, IOException 
	{
		ArrayList<texasCitiesClass>TexasCityArray = new ArrayList<texasCitiesClass>(); /**TexasCityArray contains all the data that is read from the file**/
		Populate_The_Array(TexasCityArray); /** opens the file for reading, stores the data from the file **/
		Sort_The_Array(TexasCityArray); /** implements data for each county that has been sorted **/
		System.out.println("Done Writing to the file" + "L02a_Functional_Output.txt");		
	}	
}