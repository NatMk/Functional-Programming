package lab03Package;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.OptionalInt;
import java.util.stream.Collectors;

import lab03Package.zipCodeClass;

public class FunctionalZipCode 
{
	private static void Populate_The_Array (ArrayList<zipCodeClass> TexasCityArray/*, ArrayList<String> County_List*/) throws FileNotFoundException,IOException 
	{	
		/**values of type string to store values that will be read from the input file "L02a Cityname_wo_headers.csv" **/
		String [] values;
		String line = "";
		String filename = "L03a zip_code_database.csv";
		try 
		{
			BufferedReader buffer = new BufferedReader (new FileReader(filename)); /**opens the file for reading using BufferedReader **/ 	
			
			while ((line = buffer.readLine()) != null) /** Process the file until we reach the end of it **/
			{
				values = line.split(","); /**splits the data in the file that is separated by commas**/
				TexasCityArray.add(new zipCodeClass (Integer.parseInt(values[0]),values[1],values[2],values[3],Integer.parseInt(values[4]))); 
				/** This line stores the value that is read from the file into a string of values **/
			}
			
			buffer.close(); /** closes the bufferReader, We have finished reading from the file **/
		} 
		
		catch (FileNotFoundException e) /**If a problem occurs while trying to open the input file we print a message and safely exit the program **/
		{
			   System.out.println("The File " + "L03a zip_code_database.csv" + " could not be opened for reading.\n");
			   System.exit(0);
		}					
		catch(IOException e) /**If a problem occurs while reading from the input file we print a message and safely exit the program **/
		{
		       System.out.println ("An Error occured while reading the file" + "L02b zip_code_database.csv\"\n");
		       System.exit(0);
	    }				
    }
	
	private static void Sort_The_County (ArrayList<zipCodeClass> TexasCityArray) throws IOException
	{	 
		try
		{
			String OutputFile = "Problem_3a_Output.txt";
			PrintWriter file_writer = new PrintWriter(OutputFile);
			
			/**writes a header to the opened file**/
			file_writer.println("County\tCity\tZip Type\tCity Pop\tFirst Zip\tNo.Zips\tCounty Pop");
			
			/**we sort the counties on A-Z with duplicated and find the population of each county while getting the population and zip code of each city */ 
			TexasCityArray.stream().map(county -> county.getcountyName()).distinct().sorted((county1,county2) -> county1.compareTo(county2))
			.forEach(p -> 
			{
				Sort_The_City(TexasCityArray,p,file_writer);						
		    });
			
			file_writer.close(); /* data has been written to the file */
		}	   
		catch(IOException e) /** If a problem occurs while accessing the output file we print a message and safely exit the program **/
	    {
		       System.out.println ("An Error occured while writing to the file" + "Problem_3a_Output.txt\n");
		       System.exit(0);
		}				   			   
  }
	
  private static void Sort_The_City (ArrayList<zipCodeClass>TexasCityArray,String current_county,PrintWriter file_writer)
  {
	  ArrayList<String> cnty_city_comb_copy = new ArrayList<String>();
      ArrayList<String> cty_List = new ArrayList<String>();
      ArrayList<String> City_List = new ArrayList<String>();
      
      cty_List = (ArrayList<String>) TexasCityArray.stream().filter(txc->txc.getcountyName().equals(current_county)).map(txc->txc.getcityName()).distinct().sorted().collect(Collectors.toList());
      City_List.addAll(cty_List); /*City_List contains all the cities of the counties sorted in alphabetic order */
       
      	/*populate the cnty_city_comb array list with null */
      	cnty_city_comb_copy.add("");
		cnty_city_comb_copy.add("");
		cnty_city_comb_copy.add("");
		
		 /*we stream this list in order to get the population and zip code of each city for counties that are the same*/      
	     City_List.stream()
		    
		.forEach(city->
		{
			  ArrayList<String> Zip_type = new ArrayList<String>();
		      ArrayList<String> Zip_type_List = new ArrayList<String>();
			
			int county_pop = TexasCityArray.stream().filter(c->c.getcountyName().equals(current_county)) /*city_pop contains the population of each city in the county */
				          .filter(c->c.getcityName().equals(city)).mapToInt(c->c.getestpop()).reduce(0,Integer::sum);
			
			 Zip_type = (ArrayList<String>) TexasCityArray.stream().filter(txc->txc.getcityName().equals(city)).map(txc->txc.gettypeZip()).sorted().collect(Collectors.toList());
		     Zip_type_List.addAll(Zip_type);
		     
		     ProcessOutput(TexasCityArray,cnty_city_comb_copy,Zip_type_List,current_county,city,county_pop,file_writer); 		    
	    });	
	} 

  private static void ProcessOutput(ArrayList<zipCodeClass>TexasCityArray, ArrayList<String>cnty_city_comb_copy, ArrayList<String> Zip_type_List, String current_county, String city, int county_pop, PrintWriter file_writer)
  { 
	  ArrayList<String> cnty_city_comb = new ArrayList<String>();
	  DecimalFormat IntWithComma = new DecimalFormat("###,###,###");
	  
	  /*populate the cnty_city_comb array list with null */
	  cnty_city_comb.add("");
	  cnty_city_comb.add("");
	  cnty_city_comb.add("");
	  
	  Zip_type_List.stream()
	  
	  .forEach(zip->
	  {    
		    /*update the null with city,county and zip combination */
			cnty_city_comb.set(0,current_county);
			cnty_city_comb.set(1,city);
			cnty_city_comb.set(2,zip);
			
			 /*zip_codes contains the count of the city in that county for each unique zip type*/
			 long zip_codes =  TexasCityArray.stream().filter(c->c.gettypeZip().equals(zip))
					 		.filter(c->c.getcityName().equals(cnty_city_comb.get(1))).mapToInt(c->c.getzipCode()).distinct().count(); 
			 
			 /*city_pop contains the population of each city in the county for each unique zip type */
			 int city_pop = TexasCityArray.stream().filter(c->c.getcountyName().equals(current_county)).filter(c->c.gettypeZip().equals(zip)) 					   
			          	  .filter(c->c.getcityName().equals(city)).mapToInt(c->c.getestpop()).reduce(0,Integer::sum);
			 
			 /*first_zip contains the minimum zip for each city in the county for each unique zip type*/
			OptionalInt first_zip = TexasCityArray.stream().filter(c->c.getcountyName().equals(current_county)).filter(c->c.getcityName().equals(city))
					  .filter(c->c.gettypeZip().equals(zip)).mapToInt(c->c.getzipCode()).min();
			 		 
			/*checks if the county and city has been seen before */
		   if( (cnty_city_comb.get(0).equals(cnty_city_comb_copy.get(0))) && (cnty_city_comb.get(1).equals(cnty_city_comb_copy.get(1))) ) 				    				    
		   {	
			   /*if the county and city has been seen before check if the zip is not seen, if so print it out */
			   if(! (cnty_city_comb.get(2).equals(cnty_city_comb_copy.get(2))) )
			   {	
				   /*write the data to a file*/
				   file_writer.print("\t\t"+zip+"\t"+ IntWithComma.format(city_pop)+"\t"+first_zip.hashCode() +"\t"+(int)zip_codes+"\t");		 
				   file_writer.println();				   
			   }
		   } 
		   /*checks if the county and city has never been seen before */
		   if( !( (cnty_city_comb.get(0).equals(cnty_city_comb_copy.get(0))) && (cnty_city_comb.get(1).equals(cnty_city_comb_copy.get(1))) ) )
		   {
			     /*write the data to a file*/
			     file_writer.print(current_county+"\t"+city+"\t"+zip+"\t"+IntWithComma.format(city_pop)+"\t"+first_zip.hashCode() +"\t"+(int)zip_codes+"\t"+IntWithComma.format(county_pop));
				 file_writer.println(); /*move to the next line after printing the data for a county */
		   }
		   
		   /*update the cnty_city_comb_copy array list with county,city and zip that was seen */
		   cnty_city_comb_copy.set(0,current_county);
		   cnty_city_comb_copy.set(1,city);
		   cnty_city_comb_copy.set(2,zip);		  
	  });
	   
  }

  public static void main(String[] args) throws FileNotFoundException, IOException 
  { 
		ArrayList<zipCodeClass>TexasCityArray = new ArrayList<zipCodeClass>(); /**TexasCityArray contains all the data that is read from the file**/
		Populate_The_Array(TexasCityArray); /** opens the file for reading, stores the data from the file **/
		Sort_The_County(TexasCityArray); /** implements data for each county that has been sorted **/
		System.out.println("Done Writing to the file: "+ "Problem_3a_Output.txt");		
  }
  
}
