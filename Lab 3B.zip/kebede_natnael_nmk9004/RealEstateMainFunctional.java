package lab03bPackage;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;

import lab03bPackage.ZipRateTable;
import lab03bPackage.RealEstateClass;

public class RealEstateMainFunctional
{
	private static void Populate_The_Array1 (ArrayList<RealEstateClass> TexasCityArray) throws FileNotFoundException,IOException 
	{	
		/**values is of type string to store values that will be read from the input file "House Data.csv" **/
		String [] values;
		String line = "";
		String filename = "House Data.csv";
		
		try 
		{
			BufferedReader buffer = new BufferedReader (new FileReader(filename)); /**opens the file for reading using BufferedReader **/ 	
			
			while ((line = buffer.readLine()) != null) /** Process the file until we reach the end of it **/
			{
				values = line.split(","); /**splits the data in the file that is separated by commas**/
				
				/** This line stores the value that is read from the file into a string of values **/
				TexasCityArray.add(new RealEstateClass(values[0],values[1],values[2], 
						Integer.parseInt(values[3]), Integer.parseInt(values[4]),Double.parseDouble(values[5]), 
						Double.parseDouble(values[6]), values[7], Integer.parseInt(values[8]), Integer.parseInt(values[9]),
						Integer.parseInt(values[10]), Integer.parseInt(values[11]), Integer.parseInt(values[12]),
						Integer.parseInt(values[13])/*,Integer.parseInt(values[13])*/)); 
			}		
			
			buffer.close(); /** closes the bufferReader, We have finished reading from the file **/		
		} 
		
		catch (FileNotFoundException e) /**If a problem occurs while trying to open the input file we print a message and safely exit the program **/
		{
			   System.out.println("The File " + "House Data.csv" + " could not be opened for reading.\n");
			   System.exit(0);
		}					
		catch(IOException e) /**If a problem occurs while reading from the input file we print a message and safely exit the program **/
		{
		       System.out.println ("An Error occured while reading the file" + "House Data.csv\"\n");
		       System.exit(0);
	    }				
    }
	
	private static void Populate_The_Array2 (ArrayList<ZipRateTable> TexasCityArray2) throws FileNotFoundException,IOException 
	{	
		/**values of type string to store values that will be read from the input file "ZipRateTable.csv" **/
		String [] values;
		String line = "";
		String filename = "ZipRateTable.csv";
		
		try 
		{
			BufferedReader buffer = new BufferedReader (new FileReader(filename)); /**opens the file for reading using BufferedReader **/ 	
			
			while ((line = buffer.readLine()) != null) /** Process the file until we reach the end of it **/
			{
				values = line.split(","); /**splits the data in the file that is separated by commas**/
				
				/** This line stores the value that is read from the file into a string of values **/
				TexasCityArray2.add(new ZipRateTable(Integer.parseInt(values[0]), Integer.parseInt(values[1]))); 
			}
			
			buffer.close(); /** closes the bufferReader, We have finished reading from the file **/	
		} 
		
		catch (FileNotFoundException e) /**If a problem occurs while trying to open the input file we print a message and safely exit the program **/
		{
			   System.out.println("The File " + "ZipRateTable.csv" + " could not be opened for reading.\n");
			   System.exit(0);
		}					
		catch(IOException e) /**If a problem occurs while reading from the input file we print a message and safely exit the program **/
		{
		       System.out.println ("An Error occured while reading the file" + "ZipRateTable.csv\"\n");
		       System.exit(0);
	    }				
    }
	
	private static void process_output1(ArrayList<RealEstateClass>TexasCityArray,ArrayList<ZipRateTable>TexasCityArray2)
	{	 	
	     try
		{
			String OutputFile = "HouseOrderByRating.txt";
			PrintWriter file_writer = new PrintWriter(OutputFile);
			DecimalFormat moneyFormatter = new DecimalFormat("###,###,###");
			DecimalFormat floatFormatter = new DecimalFormat("##.0");
			DecimalFormat formatter2 = new DecimalFormat("###,###,###");
			
			/**writes a header to the opened file**/
			file_writer.println("Type\tAddress\tCity\tZip\tPrice\tBeds\tBaths\tLocation\tSqft\tLot size\tYrBlt\tDOM\t$/SqFt\tHOA/mth\tRank Grp\tPercnt SqFt");

			/* house Rating 1 */
			TexasCityArray.stream()
			.filter( r -> r.getProperty_Type().equals("Single Family Residential") && r.getPrice() < 200000 && r.getDollar_Per_Sq_Ft() < 110.0
					&& r.getSquare_Feet() >= 1750 && r.getSquare_Feet() <= 2500 && r.getYear_Built() >= 2007 && r.getHOA_Per_Month() <= 25)
			
			.forEach(pt -> pt.setRating(1));
			
			/* house rating 2 */
			TexasCityArray.stream().filter(r -> r.getProperty_Type().equals("Single Family Residential") && r.getPrice() < 200000 
					&& r.getDollar_Per_Sq_Ft() < 110.0 && r.getSquare_Feet() >= 1750 && r.getSquare_Feet() <= 2500 && r.getYear_Built() >= 2007
					&& r.getHOA_Per_Month() > 25 && r.getHOA_Per_Month() <= 30)
			
			.forEach(pt -> pt.setRating(2));
						
			/*house rating 3 */
			TexasCityArray.stream().filter(r -> r.getProperty_Type().equals("Single Family Residential")
					&& r.getPrice() < 200000 && r.getDollar_Per_Sq_Ft() < 110.0 && r.getSquare_Feet() >= 1750
					&& r.getSquare_Feet() <= 2500 && r.getYear_Built() >= 2000 && r.getYear_Built() < 2007 && r.getHOA_Per_Month() <= 25)
			
			.forEach(pt -> pt.setRating(3));
			
			/*house rating 4 */
			TexasCityArray.stream().filter(r -> r.getProperty_Type().equals("Single Family Residential") && r.getPrice() < 200000 
					&& r.getDollar_Per_Sq_Ft() < 110.0 && r.getSquare_Feet() >= 1750 && r.getSquare_Feet() <= 2500 && r.getYear_Built() >= 2000
					&& r.getYear_Built() < 2007 && r.getHOA_Per_Month() > 25 && r.getHOA_Per_Month() <= 30)
			.forEach(pt -> pt.setRating(4));
			
			/* Comparator first by rating, after that by price and finally by price for square per feet */ 
			Comparator<RealEstateClass> comparator = Comparator.comparing(pt -> ((RealEstateClass)pt).getRating());
		    comparator = comparator.thenComparing(Comparator.comparing(pt -> ((RealEstateClass)pt).getPrice()));
		    comparator = comparator.thenComparing(Comparator.comparing(pt -> ((RealEstateClass)pt).getDollar_Per_Sq_Ft()));

		    /* Sort the stream:	*/		
			TexasCityArray.stream().filter(pt -> pt.getRating() >= 1 && pt.getRating() <= 4 && TexasCityArray2.stream().filter(zp -> zp.Rating() > 6 && zp.getzipCode() == pt.getZip())
									.findFirst().isPresent()).sorted(comparator)
		
			.forEach(pt -> 
			
					file_writer.println
					(
						pt.getProperty_Type() + "\t" + pt.getAddress() + "\t" + pt.getCity() + "\t" + pt.getZip() + "\t" + "$" + moneyFormatter.format(pt.getPrice()) 
						+ "\t" + pt.getBeds() + "\t" + pt.getBaths() + "\t" + pt.getLocation() + "\t" + formatter2.format(pt.getSquare_Feet()) 
						+ "\t" + formatter2.format(pt.getLot_Size()) + "\t" + pt.getYear_Built() + "\t" + pt.getDays_On_Market() 
						+ "\t" + "$" + pt.getDollar_Per_Sq_Ft() + "\t" + "$" + pt.getHOA_Per_Month() + "\t" + pt.getRating() 
						+ "\t" +
						floatFormatter.format
						(
							/*calculates the percent square feet*/
							100.0 * pt.getDollar_Per_Sq_Ft() /
							/* Calculate average */
							(
								/* Total square feet for current zip code */
								TexasCityArray.stream().filter(x->x.getZip()==(pt.getZip())).map(txc -> txc.getDollar_Per_Sq_Ft()).reduce(0, Integer::sum)
								/
								/* Total houses with specified zip code */
								(double) TexasCityArray.stream().filter(x->x.getZip()==(pt.getZip())).distinct().count()
							)
						)
					)						
			);
			
			file_writer.close(); /* data has been written to the file */			
		}	   
		catch(IOException e) /* If a problem occurs while accessing the output file we print a message and safely exit the program */
	    {
		       System.out.println ("An Error occured while writing to the file" + "HouseOrderByRating.txt");
		       System.exit(0);
		}				   			   
  }
  
  private static void process_output2(ArrayList<ZipRateTable>TexasCityArray2,ArrayList<RealEstateClass>TexasCityArray)
  {	 
		try
		{
			String OutputFile = "HouseAveragesByZip.txt";
			PrintWriter file_writer = new PrintWriter(OutputFile);
			
			/**writes a header to the opened file**/
			file_writer.println("Zip Code\tNo. Homes\tAve Price\tAve Sqft\tAve Beds\tAve Baths\tAve $/sqft\tAve DOM\tAve YrBlt\tAve HOA");
			
			TexasCityArray.stream().map(zip -> zip.getZip()).distinct().sorted((zip1,zip2) -> zip1.compareTo(zip2))
			.forEach(p -> 
			{
				String current_zip = new Integer(p).toString();
				Sort_by_zip(TexasCityArray2,TexasCityArray,current_zip,file_writer);											
		    });

			file_writer.close(); /* data has been written to the file */
			
		}	   
		catch(IOException e) /** If a problem occurs while accessing the output file we print a message and safely exit the program **/
	    {
		       System.out.println ("An Error occured while writing to the file" + "HouseAveragesByZip.txt");
		       System.exit(0);
		}				   			   
  }	

  private static void Sort_by_zip (ArrayList<ZipRateTable>TexasCityArray2,ArrayList<RealEstateClass>TexasCityArray,String current_zip,PrintWriter file_writer)
  {
	  	DecimalFormat formatter = new DecimalFormat("###,###,###");
	  	DecimalFormat flotformater = new DecimalFormat("#.0");
		DecimalFormat flotformater3 = new DecimalFormat("0.00");
		
	    int zip_val = Integer.parseInt(current_zip); 
	    long no_homes = TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).distinct().count();
	    
	    int total_price = TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).map(txc -> txc.getPrice()).reduce(0, Integer::sum);
	    int total_sqft = TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).map(txc -> txc.getSquare_Feet()).reduce(0, Integer::sum);	    
	    int Tot_HOA = TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).map(txc -> txc. getHOA_Per_Month()).reduce(0, Integer::sum);
	    int Tot_yr_built = TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).map(txc -> txc.getYear_Built()).reduce(0, Integer::sum);
	    int Tot_DOM = TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).map(txc -> txc.getDays_On_Market() ).reduce(0, Integer::sum);
	    int Tot$_sqft =  TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).map(txc -> txc.getDollar_Per_Sq_Ft()).reduce(0, Integer::sum);
	    
	    double total_Beds = TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).map(txc -> txc.getBeds()).reduce((double) 0, Double::sum);
	    double total_Baths = TexasCityArray.stream().filter(x->x.getZip()==(zip_val)).map(txc -> txc.getBaths()).reduce((double) 0, Double::sum);
	    
	    double ave_sqft = (double)total_sqft/(double)no_homes;
	    double ave_price = (double) total_price/ (double) no_homes;
	    int ave_yrBlt = Tot_yr_built/(int) no_homes;
	      
	    double ave_Beds = total_Beds/(double)no_homes; 
	    double ave_Baths = total_Baths/(double)no_homes;
	    double ave_HOA = (double) Tot_HOA/(double)no_homes;
	    double ave_DOM = (double) Tot_DOM/(double)no_homes;
	    double ave_$sqft = (double) Tot$_sqft/(double)no_homes;
	  
	    file_writer.println(zip_val+"\t"+(int)no_homes+"\t$"+ formatter.format(ave_price)+"\t"+formatter.format(ave_sqft)
	    		+"\t"+ flotformater.format(ave_Beds)+ "\t"+flotformater.format(ave_Baths) + "\t$"+flotformater3.format(ave_$sqft)
	    		+"\t"+ flotformater.format(ave_DOM) + "\t" + ave_yrBlt + "\t$" +flotformater3.format(ave_HOA) );		   
  }
  
  public static void main(String[] args) throws FileNotFoundException, IOException 
  { 
		ArrayList<RealEstateClass>TexasCityArray = new ArrayList<RealEstateClass>(); /**TexasCityArray contains all the data that is read from the file**/
		ArrayList<ZipRateTable>TexasCityArray2 = new ArrayList<ZipRateTable>(); /**TexasCityArray contains all the data that is read from the 2nd file**/
		Populate_The_Array1(TexasCityArray); /** opens the file for reading, stores the data from the file **/
		Populate_The_Array2(TexasCityArray2); /** opens the file for reading, stores the data from the file **/
		process_output1(TexasCityArray,TexasCityArray2);
		process_output2(TexasCityArray2,TexasCityArray);
		System.out.println("Done Writing to the files: " + "HouseAveragesByZip.txt and HouseOrderByRating.txt");		
  }  
}
