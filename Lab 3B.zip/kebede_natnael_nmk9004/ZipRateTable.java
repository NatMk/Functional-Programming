/*****************************************************************
 * This file contains the getters and setter methods			 *
 * for each data that was read from the file:"ZipRateTable.csv". *
 *****************************************************************/
package lab03bPackage;

public class ZipRateTable 
{
	private int zipCode;
	private int Rating;
	
	public ZipRateTable (int zipCode, int Rating) 
	{
		this.zipCode = zipCode;
		this.Rating = Rating;			
	}

	public int getzipCode() 
	{
		return zipCode;
	}
	public void setzipCode(int zipCode) 
	{
		this.zipCode = zipCode;
	}
	public int Rating() 
	{
		return Rating;
	}
	public void setRating(int Rating) 
	{
		this.Rating = Rating;
	}
}
